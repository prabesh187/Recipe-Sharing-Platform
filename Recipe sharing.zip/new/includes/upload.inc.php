<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $recipeName = $_POST["uname"];
    $recipePhoto = $_POST["recipe-photo"];
    $dishDesc = $_POST["dish-desc"];
    $ingredients = $_POST["ingredient-post"];
    $instructions = $_POST["instruction-post"];

    // Perform data validation
    if (emptyInputRecipe($recipeName, $dishDesc, $ingredients, $instructions)) {
        header("location: ../index.php?error=emptyfields");
        exit();
    }

    // Connect to the "flavourshare" database
    $conn = new mysqli("localhost", "your_username", "your_password", "flavourshare");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Upload the recipe
    uploadRecipe($conn, $recipeName, $dishDesc, $ingredients, $instructions);
    $conn->close();
} else {
    header("location: ../index.php");
    exit();
}

function uploadRecipe($conn, $recipeName, $dishDesc, $ingredients, $instructions) {
    $stmt = $conn->prepare("INSERT INTO recipes (recipe_name, dish_desc, ingredients, instructions) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $recipeName, $dishDesc, $ingredients, $instructions);
    $stmt->execute();
    $stmt->close();
    header("location: ../index.php?success=uploaded");
    exit();
}
?>