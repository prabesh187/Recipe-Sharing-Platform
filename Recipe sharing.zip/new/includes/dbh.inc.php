<?php
$serverName= "localhost";
$dBUsername= "root";
$dBPassword= "";
$dBName= "flavourshare";

$conn = mysqli_connect($serverName,$dBUsername,$dBPassword,$dBName);

if (!$conn) {
    die("Connection failed:" . mysqli_connect_error());

}
function retrieve($query) {
    global $con;
    $res = mysqli_query($con, $query);
    if (!$res) echo ("Error: " . mysqli_error($con));

    $items = [];
    while ($item = mysqli_fetch_assoc($res)) {
        $items[] = $item;
    }

    return $items;
}

?>