<?php
function uploadRecipe($conn, $recipeName, $dishDesc, $ingredients, $instructions, $recipePhoto){
    $targetDir = "uploads/"; // Directory to store uploaded photos
    $targetFile = $targetDir . basename($_FILES["recipe-photo"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    if(isset($_POST["createbtn"])) {
        $check = getimagesize($_FILES["recipe-photo"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            header("location: ../index.php?error=invalidphoto");
            exit();
        }
    }

    // Check file size
    if ($_FILES["recipe-photo"]["size"] > 500000) {
        header("location: ../index.php?error=largephoto");
        exit();
    }

    // Allow only certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        header("location: ../index.php?error=invalidformat");
        exit();
    }

    // Move the uploaded file to the target directory
    if (move_uploaded_file($_FILES["recipe-photo"]["tmp_name"], $targetFile)) {
        // Insert the recipe details into the database, including the file path
        $sql = "INSERT INTO recipes (recipe_name, dish_desc, ingredients, instructions, photo_path) VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../index.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "sssss", $recipeName, $dishDesc, $ingredients, $instructions, $targetFile);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: ../index.php?success=uploaded");
        exit();
    } else {
        header("location: ../index.php?error=uploadfailed");
        exit();
    }
}

?>