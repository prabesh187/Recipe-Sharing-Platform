
<?php
    header("Content-type: text/css; charset: UTF-8");
?>

@import url('https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Signika:wght@300;400;600;700&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Pacifico&display=swap');

.add-btn {
    background: rgb(67, 68, 67);
    display: block;
    width: 50px;
    height: 50px;
    line-height: 50px;
    text-align: center;
    color: white;
    font-size: 30px;
    font-weight: bold;
    border-radius: 50%;
    -webkit-border-radius: 50%;
    text-decoration: none;
    transition: ease all 0.3s;
    position: fixed;
    right: 30px;
    bottom: 30px;
  }
  
  .add-btn:hover {
    background: rgb(12, 12, 12)
  }

  /* Set a style for all buttons */
.modal_btn {
    background-color: #04AA6D;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
  }
  
  .modal_btn:hover {
    opacity: 0.8;
  }

/* Set a style for all buttons */
.modal_btn {
    background-color: #04AA6D;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;modal
  }
  
  .modal_btn:hover {
    opacity: 0.8;
  }
  
  /* Extra styles for the cancel button */
  .closebtn,
  .createbtn,
  .deletebtn,
  .editbtn {
    color: white;
    width: auto;
    padding: 10px 18px;
    font-size: 14px;
    border: none;
    cursor: pointer;
    border-radius: 6px;
  }
  
  /* Extra styles for the cancel button */
  
  .closebtn {
    background-color: rgb(121, 121, 121);
  }
  
  .createbtn {
    background-color: #07b641d5;
  }
  
  .deletebtn {
    background-color: #eb3131d5;
  }
  
  .editbtn {
    background-color: #2663e7d5;
  }
  
  .closebtn:hover {
    background-color: rgb(59, 59, 59);
  }
  
  .createbtn:hover {
    background-color: #057c2d;
  }
  
  .likebtn {
    padding: 5px 20px;
    background-color: rgba(0, 0, 0, 0);
    border-radius: 2px;
    border: 3px solid rgb(255, 67, 67);
    font-weight: bold;
    text-align: left;
    color: rgb(255, 67, 67);
  }
  .likebtn:hover, .likebtn-liked {
    background-color: rgb(255, 0, 0);
    color: whitesmoke;
    cursor: pointer;
  }
  .likebtn:active {
    color: whitesmoke;
    background-color: rgb(219, 43, 43);
  }
  
  /* Center the image and position the close button */
  .iconcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
  }
  
  .modal_container {
    padding-top: 15px;
    padding-bottom: 12px;
    padding-left: 25px;
    font-size: 17px;
  }
  
  .modal_container2 {
    padding-left: 80px;
    flex-wrap: wrap;
    display: flex;
    display: grid;
    height: 60%;
    align-content: space-evenly;
    grid-template-columns: auto;
    grid-gap: 2px;
    padding: 2px;
  }
  
  .modal_container2>div {
    background-color: rgba(255, 255, 255, 0.8);
    text-align: left;
    padding: 9px 0;
    font-size: 25px;
  }
  
  
  /* The Modal (background) */
  .modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgb(0, 0, 0);
    /* Fallback color */
    background-color: rgba(0, 0, 0, 0.4);
    /* Black w/ opacity */
    padding-top: 50px;
  }
  
  /* Modal Content/Box */
  .modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto;
    /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    border-radius: 7px;
    width: 49%;
    /* Could be more or less, depending on screen size */
  }
  
  /* The Close Button (x) */
  .close {
    position: absolute;
    right: 25px;
    top: 0;
    color: rgb(92, 92, 92);
    font-size: 35px;
  }
  
  .close:hover,
  .close:focus {
    color: rgb(0, 0, 0);
    font-weight: 500;
    cursor: pointer;
  }
  
  /* Add Zoom Animation */
  .animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
  }
  
  @-webkit-keyframes animatezoom {
    from {
      -webkit-transform: scale(0)
    }
  
    to {
      -webkit-transform: scale(1)
    }
  }
  
  @keyframes animatezoom {
    from {
      transform: scale(0)
    }
  
    to {
      transform: scale(1)
    }
  }
  
  /* Change styles for span and cancel button on extra small screens */
  @media screen and (max-width: 500px) {
    .modal-content {
      width: 79%;
    }
  
    .closebtn,
    .createbtn {
      width: 100%;
    }
  }
  
  
  
  /* Create-recipe */
  #recipe-photo {
    display: none;
  }
  
  #recipe-photo-click {
    display: inline-block;
    padding: 5px 10px;
    background-color: rgb(37, 37, 37);
    border-radius: 10px;
    color: white;
    font-size: 16px;
  }
  
  #recipe-photo-click:hover {
    background-color: black;
    cursor: pointer;
  }
  
  #previewCon {
    border: 2px solid rgb(133, 133, 133);
    border-style: dashed;
    width: 150px;
    height: 100px;
  }
  
  #img-preview {
    display: none;
    border-radius: 10px;
  }
  
  .label-post {
    font-size: 1.5rem;
    font-weight: 600;
  }
  
  #dish-desc {
    height: 100px;
    resize: none;
  }
  
  .no-hspan {
    resize: vertical;
  }
  
  .form-control {
    width: 89%;
    height: auto;
    min-height: 120px;
    padding-top: 10px;
    margin-top: 10px;
    border-radius: 5px;
    border-color: 1px solid rgb(216, 216, 216);
  }
  
  .upload-title {
    font-family: 'Alfa Slab One', cursive;
    margin-left: 15px;
    margin-top: 10px;
    font-size: 2.1rem;
    user-select: none;
  }
  
  .card_ {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    width: 320px;
    height: 300px;
    margin-left: 40px;
    text-align: left;
    font-family: arial;
    border-radius: 19px 19px 22px 22px;
    /* border: 1px solid thistle; */
    background-color: whitesmoke;
  }
  
  .card_ img {
    border-radius: 19px 19px 0 0;
  }
  
  .card_title {
    color: grey;
    font-size: 14px;
  }
  
  .card_btn {
    border: none;
    outline: 0;
    display: inline-block;
    padding: 15px;
    color: rgb(146, 146, 146);
    background-color: rgb(236, 236, 236);
    text-align: left;
    cursor: pointer;
    width: 100%;
    font-size: 12px;
    border-radius: 0 0 22px 22px;
  }
  
  .card_:hover {
    opacity: 0.79;
  }
  
  .card_contents {
    padding: 19px;
    background-color: #ffffff;
    min-height: 90px;
    height: auto;
  }
  
  #recipe-cards {
    display: grid;
    grid-column-gap: 2px;
    grid-row-gap: 120px;
    grid-template-columns: 30% 30% 30%;
    align-items: center;
    width: 80%;
    margin: 20px auto;
    text-align: left;
  }
  
  .update-ta {
    resize: vertical;
    padding: 5px;
    border-radius: 5px;
    border: 1px solid grey;
  }
  
  .modal-btn {
    display: inline-block;
  }
  
  
 