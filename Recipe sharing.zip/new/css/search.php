<?php
    header("Content-type: text/css; charset: UTF-8");
?>

/* CSS styles for the search bar */
.nav-search {
    margin-right: 25px;
    float: right;
  }
  
  .nav-search .search-form {
    display: flex;
    align-items: center;
  }
  
  .nav-search input[type="text"] {
    padding: 6px;
    border: none;
    border-radius: 8px;
    margin-right: 8px;
    width: 200px;
  }
  
  .nav-search .search-button {
    padding: 6px 10px;
    background-color: #ff9b05;
    color: #fff;
    border: none;
    border-radius: 8px;
    margin-right: 2px;
  }
  
  .nav-search .search-button:hover {
    background-color: #ffb13c;
  }
  
  /* CSS class to hide the search bar */
  .search-hidden {
    display: none;
  }
  
  
@media screen and (min-width: 992px) {
  .nav-search {
    float: left;
}
}