<?php
   include_once 'header.php';
?>

    <!-- main -->
    <main class="page">
      <!-- header -->
      <header class="hero">
        <div class="hero-container">
          <div class="hero-text">
   
            <h1>Flavour Share</h1>
            <?php 
  if (isset($_SESSION["useruid"])) {
     echo "<h4>Hello there " . $_SESSION["useruid"] . "</h4>";
      }
  
?>
            
          </div>
        </div>
      </header>
      <!-- recipes container -->
      <section class="recipes-container">
        <!-- tags container -->
        <div class="tags-container">
          <h4>recipes</h4>
          <div class="tags-list">
            <a href="tag-template.php"> Momo</a>
            <a href="tag-template.php"> Pizza</a>
            <a href="tag-template.php"> Vegetable Soup</a>
          </div>
        </div>
        <!-- recipes list -->
        <div class="recipe-list">
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/recipe-1.jpg"
              alt="Food"
              class="img recipe-img"
            />
            <h5>Momo</h5>
            <p>Prep : 30 min | cook : 40min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/recipe-2.jpg"
              alt="Food"
              class="img recipe-img"
            />
            <h5>pizza</h5>
            <p>Prep : 15min | cook : 20min</p>
          </a>
          <!-- end of single recipe -->
          <!-- single recipe -->
          <a href="single-recipe.php" class="recipe">
            <img
              src="./assets/recipes/recipe-3.jpg"
              alt="Food"
              class="img recipe-img"
            />
            <h5>vegetable soup</h5>
            <p>Prep : 15min | cook : 5min</p>
          </a>
          <!-- end of single recipe -->



        </div>
        <a href="#" title="Add dish..." data-target="#addDish" class="add-btn"
            onclick="document.getElementById('id01').style.display='block'">+</a>
         <?php include("create-recipe.php"); ?>
         
      </section>
    </main>
    <footer class="page-footer">
      <p>
        &copy; <span id="date"></span
        ><span class="footer-logo"> Flavour Share</span> Built by
        <a href="#">Janak Niroula</a>
      </p>
    </footer>
    <script src="js/app.js"></script>
  </body>
</html>
