<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Flavour Share</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="./assets/icon.png" type="image/x-icon" />
    <!-- normalize -->
    <link rel="stylesheet" href="./css/normalize.css" />
    <!-- font-awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
    <!-- main css -->
    <link rel="stylesheet" href="./css/main.php" />
    <link rel="stylesheet" href="./css/search.php"/>
    <link rel="stylesheet" href="./css/uploadstyle.php"/>
  </head>
  <body>
    <nav class="navbar">
      <div class="nav-center">
        <div class="nav-header">
          <a href="index.php" class="nav-logo">
            <img src="./assets/logo3.png" alt="simply" />
          </a>
          <button type="button" class="btn nav-btn">
            <i class="fas fa-align-justify"></i>
          </button>
        </div>
        <div class="nav-search">
          <form class="search-form" method="GET" action="search.php">
            <input class='search-recipe' type="text" name="search" placeholder="Search recipes..." />
            <button type="submit" class="search-button">
              <i class="fas fa-search"></i>
            </button>
          </form>
        </div>
        <!-- links -->
        <div class="nav-links show-links">
          <a href="index.php" class="nav-link">home</a>
          <a href="upload.php" class="nav-link">upload</a>
          <a href="browse.php" class="nav-link">recipes</a>
          <a href="about.php" class="nav-link">about</a>
          <div class="nav-link contact-link">
            <?php
              if (isset($_SESSION["useruid"])) {
                echo "<a href='includes/logout.inc.php' class='btn'>Log out</a>";
              } else {
                echo "<a href='SignIn.php' class='btn'>Sign In</a>";
              }
            ?>
          </div>
        </div>
      </div>
    </nav>
  </body>
</html>
